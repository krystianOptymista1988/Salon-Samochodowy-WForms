Dzień dobry,

  Nie za bardzo miałem kogo z grupy zapytać o ten program więc postanowiłem zrobić go w Formsach (to wymaganie zapowiadał Pan na pierwszych ćwiczeniach). 

Mam nadzieję, że Program jest zgodny z tym czego Pan od nas wymagał.

Na ostatnich ćwiczeniach nie było mnie ze względu na pobyt w szpitalu i napisałem do Pana dwa maile w tej sprawie załączając wypis ze szpitala. 

